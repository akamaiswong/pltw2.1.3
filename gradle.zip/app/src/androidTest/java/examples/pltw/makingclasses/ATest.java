package examples.pltw.makingclasses;

import junit.framework.TestCase;


public class ATest extends TestCase{

    A a;

    @Override
    public void setUp()throws Exception{
        super.setUp();
        a = new A();
    }

    public void testArithmeticAdd() {
        assertEquals(a.add(), 5);
    }

    @Override
    public void tearDown() throws Exception{
        super.tearDown();
    }

}