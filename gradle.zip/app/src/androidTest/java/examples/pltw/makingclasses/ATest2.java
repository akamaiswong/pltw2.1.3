package examples.pltw.makingclasses;

import junit.framework.TestCase;

/**
 * Created by wdumas on 2/24/2015.
 */
public class ATest2 extends TestCase {

    A a;

    @Override
    public void setUp()throws Exception{
        super.setUp();
        a = new A(); //add (5, 10) to see if this works
    }

    public void testArithmeticAdd() {
        System.out.println(A.add(2, 2));
        System.out.println(A.add(2, -5));
    }

    public void testArithmeticSubtract() {
        System.out.println(A.subtract(2, 2));
        System.out.println(A.subtract(2, -5));
    }

    public void testArithmeticMultiply() {
        System.out.println(A.multiply(2, 2));
        System.out.println(A.multiply(2, -5));
    }

    public void testArithmeticDivide() {
        System.out.println(A.divide(2, 2));
        System.out.println(A.divide(2, -5));
    }

    @Override
    public void tearDown() throws Exception{
        super.tearDown();
    }

}
