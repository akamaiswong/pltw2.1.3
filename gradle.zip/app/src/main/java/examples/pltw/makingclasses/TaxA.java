package examples.pltw.makingclasses;

public class TaxA extends A
{
    public double calculateTax(double amount, double tax)
    {
        double a = amount;
        double t = tax / 100;

        double p =  a * t;

        return p;
    }

    public double calculateTax(double taxRate) {
        int purchaseAmount = mOperand1 + mOperand2;
        // follow with the rest of your algorithm
        return purchaseAmount;
    }

}
