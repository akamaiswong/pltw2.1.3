package examples.pltw.makingclasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        A testArithmetic = new A();
        System.out.println(testArithmetic);

        TaxA tax = new TaxA();
        System.out.println(tax);
    }

}
