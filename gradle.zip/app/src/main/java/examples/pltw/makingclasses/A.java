package examples.pltw.makingclasses;

public class A
{
    public int mOperand2;
    public int mOperand1;

    public A()
    {
        mOperand1 = 2;
        mOperand2 = 3;
    }

    public String toString()
    {
        return "Arithmetic Instance:  mOperand1 = " + mOperand1 + "; mOperand2 = " + mOperand2 + ".";
    }

    public static int add(int operand1, int operand2){
        return operand1 + operand2;
    }

    public static int divide(int operand1, int operand2){
        return operand1 / operand2;
    }

    public static int subtract(int operand1, int operand2){
        return operand1 - operand2;
    }

    public static int multiply(int operand1, int operand2){
        return operand1 * operand2;
    }
}
